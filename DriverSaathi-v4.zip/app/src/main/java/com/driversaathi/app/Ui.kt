package com.driversaathi.app

import android.provider.Settings
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ------------------------------------------------------------------ design (ChatGPT-like: clean white, soft grey, green accent)

object DS {
    val bg = Color(0xFFFFFFFF)
    val surface = Color(0xFFFFFFFF)
    val surface2 = Color(0xFFF4F4F4)
    val line = Color(0xFFE5E5E5)
    val text = Color(0xFF0D0D0D)
    val muted = Color(0xFF6E6E80)
    val accent = Color(0xFF10A37F)
    val good = Color(0xFF10A37F)
    val warn = Color(0xFFD97706)
    val danger = Color(0xFFD92D20)
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = DS.accent,
            onPrimary = Color.White,
            background = DS.bg,
            surface = DS.surface,
            onBackground = DS.text,
            onSurface = DS.text
        ),
        content = content
    )
}

// ------------------------------------------------------------------ building blocks

@Composable
fun Panel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Column(
        modifier.fillMaxWidth().clip(shape).background(DS.surface).border(1.dp, DS.line, shape),
        content = content
    )
}

@Composable
fun H1(text: String) = Text(text, color = DS.text, fontSize = 26.sp, fontWeight = FontWeight.Bold)

@Composable
fun Muted(text: String, size: Int = 14) = Text(text, color = DS.muted, fontSize = size.sp)

@Composable
fun PrimaryButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Box(
        modifier.fillMaxWidth().height(52.dp).clip(shape)
            .background(if (enabled) DS.text else DS.surface2)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = if (enabled) Color.White else DS.muted, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
    }
}

@Composable
fun GhostButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    Box(
        modifier.height(44.dp).clip(shape).background(DS.surface).border(1.dp, DS.line, shape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(text, color = DS.text, fontWeight = FontWeight.Medium, fontSize = 14.sp) }
}

@Composable
fun Bubble(text: String, mine: Boolean, meta: String? = null) {
    val shape = RoundedCornerShape(18.dp)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
        Column(
            Modifier.widthIn(max = 300.dp).clip(shape).background(if (mine) DS.accent else DS.surface2)
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            if (meta != null) Text(meta, color = if (mine) Color(0xCCFFFFFF) else DS.muted, fontSize = 12.sp)
            Text(text, color = if (mine) Color.White else DS.text, fontSize = 15.sp)
        }
    }
}

@Composable
private fun Logo(size: Int = 64) {
    Box(Modifier.size(size.dp).clip(CircleShape).background(DS.text), contentAlignment = Alignment.Center) {
        Text("🚖", fontSize = (size / 2).sp)
    }
}

@Composable
private fun LangChip(act: MainActivity) {
    val shape = RoundedCornerShape(50)
    Row(
        Modifier.clip(shape).border(1.dp, DS.line, shape)
            .clickable { Store.setLang(act, if (Store.lang == "hi") "en" else "hi") }
            .padding(horizontal = 12.dp, vertical = 7.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("🌐", fontSize = 14.sp)
        Text(if (Store.lang == "hi") "हिंदी → EN" else "EN → हिंदी", color = DS.text, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

// ------------------------------------------------------------------ root / navigation

@Composable
fun Root(act: MainActivity) {
    val tick = Store.tick
    var tab by remember { mutableIntStateOf(0) }

    if (!Store.langChosen(act)) { LanguageScreen(act); return }
    if (!Store.consent(act)) { ConsentScreen(act); return }
    if (Config.OTP_ENABLED && !Store.loggedIn(act)) { LoginFlow(act); return }

    val labels = listOf(L.t("चैट", "Chat"), L.t("ड्यूटी", "Duty"), L.t("संदेश", "Messages"), L.t("सेटिंग", "Settings"))
    val icons = listOf("💬", "🚗", "📩", "⚙️")

    Scaffold(
        containerColor = DS.bg,
        topBar = {
            Row(
                Modifier.fillMaxWidth().background(DS.bg).padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Driver Saathi", color = DS.text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                LangChip(act)
            }
        },
        bottomBar = {
            NavigationBar(containerColor = DS.surface) {
                labels.forEachIndexed { i, label ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Text(icons[i], fontSize = 20.sp) },
                        label = { Text(label, fontSize = 12.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedTextColor = DS.text, unselectedTextColor = DS.muted, indicatorColor = DS.surface2
                        )
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> ChatScreen(act)
                1 -> HomeScreen(act, tick) { tab = 3 }
                2 -> MessagesScreen(act, tick)
                else -> SettingsScreen(act, tick)
            }
        }
    }
}

// ------------------------------------------------------------------ language, consent

@Composable
fun LanguageScreen(act: MainActivity) {
    Column(
        Modifier.fillMaxSize().background(DS.bg).padding(28.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Logo(84)
        Spacer(Modifier.height(20.dp))
        H1("Driver Saathi")
        Spacer(Modifier.height(6.dp))
        Muted("भाषा चुनें  •  Choose your language", 15)
        Spacer(Modifier.height(32.dp))
        PrimaryButton("हिंदी") { Store.setLang(act, "hi") }
        Spacer(Modifier.height(12.dp))
        PrimaryButton("English") { Store.setLang(act, "en") }
    }
}

@Composable
fun ConsentScreen(act: MainActivity) {
    var checked by remember { mutableStateOf(false) }
    Column(
        Modifier.fillMaxSize().background(DS.bg).verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Spacer(Modifier.height(24.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Logo(56)
            LangChip(act)
        }
        H1(L.t("आपकी सहमति", "Your consent"))
        Muted(L.t("शुरू करने से पहले ये तीन बातें जान लीजिए", "Please know these three things before you start"), 15)
        Panel {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                ConsentRow("✍️", L.t("ऐप सिर्फ़ आपके बोलने पर चैट बॉक्स में मैसेज लिखेगा।", "The app only writes a message in the chat box when you speak."))
                ConsentRow("👆", L.t("Send, Accept और Reject का बटन हमेशा आप ही दबाएँगे।", "You always press Send, Accept and Reject yourself."))
                ConsentRow("🎙️", L.t("आपकी आवाज़ रिकॉर्ड या सेव नहीं होती।", "Your voice is never recorded or saved."))
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(
                checked = checked, onCheckedChange = { checked = it },
                colors = CheckboxDefaults.colors(checkedColor = DS.accent, uncheckedColor = DS.muted, checkmarkColor = Color.White)
            )
            Text(L.t("मैं सहमत हूँ", "I agree"), color = DS.text)
        }
        PrimaryButton(L.t("आगे बढ़ें", "Continue"), enabled = checked) { Store.setConsent(act) }
    }
}

@Composable
private fun ConsentRow(icon: String, text: String) {
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.Top) {
        Text(icon, fontSize = 20.sp)
        Text(text, color = DS.text, fontSize = 15.sp)
    }
}

// ------------------------------------------------------------------ login / register with OTP

@Composable
fun LoginFlow(act: MainActivity) {
    var step by remember { mutableIntStateOf(0) }
    var phone by remember { mutableStateOf("") }
    var otp by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf("") }

    fun sendOtp() {
        busy = true; err = ""
        Api.sendOtp(act, phone) { ok, msg ->
            busy = false
            if (ok) { step = 1; otp = "" } else err = msg
        }
    }

    Column(
        Modifier.fillMaxSize().background(DS.bg).verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Spacer(Modifier.height(24.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Logo(56)
            LangChip(act)
        }
        if (step == 0) {
            H1(L.t("लॉगिन / रजिस्टर", "Login / Register"))
            Muted(L.t("अपना मोबाइल नंबर डालिए। हम OTP भेजेंगे। नया नंबर अपने आप रजिस्टर हो जाएगा।",
                "Enter your mobile number. We will send an OTP. A new number is registered automatically."), 15)
            OutlinedTextField(
                value = phone,
                onValueChange = { v -> phone = v.filter { it.isDigit() }.take(10) },
                modifier = Modifier.fillMaxWidth(),
                prefix = { Text("+91 ") },
                label = { Text(L.t("मोबाइल नंबर", "Mobile number")) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
            )
            if (err.isNotBlank()) Text(err, color = DS.danger, fontSize = 14.sp)
            PrimaryButton(
                if (busy) L.t("भेज रहे हैं…", "Sending…") else L.t("OTP भेजें", "Send OTP"),
                enabled = phone.length == 10 && !busy
            ) { sendOtp() }
        } else {
            H1(L.t("OTP डालिए", "Enter OTP"))
            Muted(L.t("+91 $phone पर 6 अंकों का OTP भेजा गया है।", "A 6-digit OTP was sent to +91 $phone."), 15)
            OutlinedTextField(
                value = otp,
                onValueChange = { v -> otp = v.filter { it.isDigit() }.take(6) },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("OTP") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
            )
            if (err.isNotBlank()) Text(err, color = DS.danger, fontSize = 14.sp)
            PrimaryButton(
                if (busy) L.t("जाँच रहे हैं…", "Verifying…") else L.t("आगे बढ़ें", "Verify & continue"),
                enabled = otp.length >= 4 && !busy
            ) {
                busy = true; err = ""
                Api.verifyOtp(act, phone, otp) { ok, msg -> busy = false; if (!ok) err = msg }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                GhostButton(L.t("OTP दोबारा भेजें", "Resend OTP"), Modifier.weight(1f)) { if (!busy) sendOtp() }
                GhostButton(L.t("नंबर बदलें", "Change number"), Modifier.weight(1f)) { step = 0; err = "" }
            }
        }
    }
}

// ------------------------------------------------------------------ AI chat (ChatGPT style)

@Composable
fun ChatScreen(act: MainActivity) {
    val msgs = Store.chat
    val busy = Store.chatBusy
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(msgs.size, busy) {
        val n = msgs.size + (if (busy) 1 else 0)
        if (n > 0) listState.animateScrollToItem(n - 1)
    }

    fun send(t: String) {
        if (t.isBlank() || busy) return
        input = ""
        act.sendChat(t)
    }

    Column(Modifier.fillMaxSize()) {
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (msgs.isEmpty()) {
                Column(
                    Modifier.fillMaxSize().padding(24.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Logo(64)
                    Spacer(Modifier.height(16.dp))
                    Text(L.t("आज मैं कैसे मदद करूँ?", "How can I help you today?"), color = DS.text, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(20.dp))
                    val ideas = listOf(
                        L.t("आज ज़्यादा कमाई कैसे करूँ?", "How do I earn more today?"),
                        L.t("ग्राहक को 5 मिनट में पहुँचने का मैसेज लिखो", "Write a message: I will reach in 5 minutes"),
                        L.t("रात की ड्राइविंग के सेफ्टी टिप्स बताओ", "Give me night driving safety tips")
                    )
                    ideas.forEach { idea ->
                        Box(
                            Modifier.padding(vertical = 5.dp).fillMaxWidth().clip(RoundedCornerShape(14.dp))
                                .border(1.dp, DS.line, RoundedCornerShape(14.dp)).clickable { send(idea) }.padding(14.dp)
                        ) { Text(idea, color = DS.text, fontSize = 14.sp) }
                    }
                }
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    items(msgs) { m ->
                        if (m.mine) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                Box(Modifier.widthIn(max = 290.dp).clip(RoundedCornerShape(20.dp)).background(DS.surface2).padding(horizontal = 14.dp, vertical = 10.dp)) {
                                    Text(m.text, color = DS.text, fontSize = 16.sp)
                                }
                            }
                        } else {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.Top) {
                                Box(Modifier.size(28.dp).clip(CircleShape).background(DS.text), contentAlignment = Alignment.Center) { Text("🚖", fontSize = 14.sp) }
                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text(m.text, color = if (m.error) DS.danger else DS.text, fontSize = 16.sp, lineHeight = 24.sp)
                                    if (!m.error) {
                                        Text("📋 " + L.t("कॉपी", "Copy"), color = DS.muted, fontSize = 12.sp, modifier = Modifier.clickable { act.copy(m.text) })
                                    }
                                }
                            }
                        }
                    }
                    if (busy) {
                        item { Muted(L.t("सोच रहा हूँ…", "Thinking…"), 15) }
                    }
                    item { Spacer(Modifier.height(4.dp)) }
                }
            }
        }

        // input bar
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                Modifier.weight(1f).clip(RoundedCornerShape(26.dp)).background(DS.surface2),
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text(L.t("कुछ भी पूछें", "Ask anything"), color = DS.muted) },
                    maxLines = 4,
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent,
                        cursorColor = DS.accent
                    )
                )
                Box(
                    Modifier.padding(end = 6.dp).size(40.dp).clip(CircleShape).clickable { act.listen { send(it) } },
                    contentAlignment = Alignment.Center
                ) { Text("🎤", fontSize = 20.sp) }
            }
            Box(
                Modifier.size(46.dp).clip(CircleShape)
                    .background(if (input.isNotBlank() && !busy) DS.text else DS.line)
                    .clickable(enabled = input.isNotBlank() && !busy) { send(input) },
                contentAlignment = Alignment.Center
            ) { Text("↑", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold) }
        }
    }
}

// ------------------------------------------------------------------ duty / voice

@Composable
fun HomeScreen(act: MainActivity, tick: Int, goSetup: () -> Unit) {
    val online = Store.online(act)
    val last = Store.messages(act).firstOrNull()
    val ready = Perms.notifAccess(act)

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
                H1(L.t("नमस्ते 👋", "Hello 👋"))
                Muted(L.t("आज की सवारी आराम से", "Have a smooth ride day"))
            }
            StatusPill(online)
        }

        VoiceOrb(online = online, onTap = { act.voiceDraft() })

        Panel {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(Modifier.weight(1f)) {
                    Text(if (online) L.t("ड्यूटी चालू", "Duty ON") else L.t("ड्यूटी बंद", "Duty OFF"), color = DS.text, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Muted(
                        if (online) L.t("आने वाले मैसेज बोलकर सुनाऊँगा", "I will read incoming messages aloud")
                        else L.t("चालू करने पर मैसेज बोलकर सुनाऊँगा", "Turn on to hear messages read aloud")
                    )
                }
                Switch(
                    checked = online,
                    onCheckedChange = { Store.setOnline(act, it) },
                    colors = SwitchDefaults.colors(
                        checkedTrackColor = DS.good, checkedThumbColor = Color.White, checkedBorderColor = DS.good,
                        uncheckedTrackColor = DS.surface2, uncheckedThumbColor = DS.muted, uncheckedBorderColor = DS.line
                    )
                )
            }
        }

        if (!ready) {
            Panel {
                Row(
                    Modifier.fillMaxWidth().padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("⚠️ " + L.t("सेटअप अधूरा है", "Setup incomplete"), color = DS.warn, fontWeight = FontWeight.Bold)
                        Muted(L.t("मैसेज पढ़ने की अनुमति चाहिए", "Notification access is needed"))
                    }
                    GhostButton(L.t("पूरा करें", "Fix"), Modifier.widthIn(min = 100.dp), goSetup)
                }
            }
        }

        Panel {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Muted(L.t("आख़िरी मैसेज", "Latest message"))
                if (last == null) {
                    Text(L.t("अभी कोई मैसेज नहीं आया।", "No messages yet."), color = DS.text)
                } else {
                    val body = if (last.title.isBlank()) last.text else "${last.title}\n${last.text}"
                    Bubble(body, mine = false, meta = last.platform)
                    if (last.draft.isNotBlank()) Bubble(last.draft, mine = true, meta = L.t("आपका ड्राफ़्ट", "Your draft"))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        GhostButton("🔊 " + L.t("दोबारा सुनो", "Listen again"), Modifier.weight(1f)) {
                            Speaker.speak("${last.platform}. ${last.title}. ${last.text}")
                        }
                        if (last.draft.isNotBlank()) {
                            GhostButton("📋 " + L.t("कॉपी", "Copy"), Modifier.weight(1f)) { act.copy(last.draft) }
                        }
                    }
                }
            }
        }

        Muted(L.t("ऐप खोलें", "Open app"))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf("ola" to "Ola", "uber" to "Uber", "rapido" to "Rapido").forEach { (key, label) ->
                GhostButton(label, Modifier.weight(1f)) { act.openRide(key) }
            }
        }
        Muted(L.t("Send हमेशा आप दबाते हैं।", "You always press Send yourself."), 13)
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun StatusPill(online: Boolean) {
    val shape = RoundedCornerShape(50)
    Row(
        Modifier.clip(shape).border(1.dp, DS.line, shape).padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Box(Modifier.size(9.dp).clip(CircleShape).background(if (online) DS.good else DS.muted))
        Text(if (online) L.t("ऑनलाइन", "Online") else L.t("ऑफ़लाइन", "Offline"), color = DS.text, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun VoiceOrb(online: Boolean, onTap: () -> Unit) {
    val inf = rememberInfiniteTransition(label = "orb")
    val s by inf.animateFloat(
        initialValue = 1f,
        targetValue = 1.35f,
        animationSpec = infiniteRepeatable(tween(1600, easing = FastOutSlowInEasing), RepeatMode.Restart),
        label = "scale"
    )
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(Modifier.size(200.dp), contentAlignment = Alignment.Center) {
            if (online) {
                Box(
                    Modifier.size(150.dp)
                        .graphicsLayer {
                            scaleX = s
                            scaleY = s
                            alpha = ((1.35f - s) / 0.35f).coerceIn(0f, 1f) * 0.45f
                        }
                        .clip(CircleShape).background(DS.accent)
                )
            }
            Box(
                Modifier.size(120.dp).clip(CircleShape)
                    .background(if (online) DS.accent else DS.surface2)
                    .clickable(onClick = onTap),
                contentAlignment = Alignment.Center
            ) { Text("🎤", fontSize = 44.sp) }
        }
        Text(L.t("दबाकर बोलिए", "Tap and speak"), color = DS.text, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Muted(
            if (online) L.t("जवाब बोलिए, AI ड्राफ़्ट लिख देगा", "Say your reply, AI will write the draft")
            else L.t("ड्यूटी चालू करके मैसेज सुनिए", "Turn duty on to hear messages")
        )
    }
}

// ------------------------------------------------------------------ messages

@Composable
fun MessagesScreen(act: MainActivity, tick: Int) {
    val list = Store.messages(act)
    val fmt = remember { SimpleDateFormat("hh:mm a", Locale.getDefault()) }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 8.dp)) {
        H1(L.t("संदेश", "Messages"))
        Spacer(Modifier.height(12.dp))
        if (list.isEmpty()) {
            Panel {
                Column(
                    Modifier.fillMaxWidth().padding(28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("💬", fontSize = 36.sp)
                    Text(L.t("अभी कोई मैसेज नहीं आया।", "No messages yet."), color = DS.text, fontWeight = FontWeight.Bold)
                    Muted(L.t("ग्राहक का मैसेज आते ही यहाँ दिखेगा", "Customer messages will show up here"))
                }
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                items(list) { m ->
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        val body = if (m.title.isBlank()) m.text else "${m.title}\n${m.text}"
                        Bubble(body, mine = false, meta = "${m.platform} • ${fmt.format(Date(m.time))}")
                        if (m.draft.isNotBlank()) Bubble(m.draft, mine = true, meta = L.t("आपका ड्राफ़्ट", "Your draft"))
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ settings

@Composable
private fun SetupRow(icon: String, title: String, desc: String, ok: Boolean, onFix: () -> Unit) {
    Panel {
        Row(
            Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(Modifier.size(40.dp).clip(CircleShape).background(DS.surface2), contentAlignment = Alignment.Center) { Text(icon, fontSize = 18.sp) }
            Column(Modifier.weight(1f)) {
                Text(title, color = DS.text, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                Muted(desc, 13)
            }
            if (ok) Text("✅", fontSize = 22.sp) else GhostButton(L.t("ठीक करें", "Fix"), Modifier.widthIn(min = 84.dp), onFix)
        }
    }
}

@Composable
fun SettingsScreen(act: MainActivity, tick: Int) {
    val n = Perms.notifAccess(act)
    val m = Perms.mic(act)
    val a = Perms.a11y(act)
    val b = Perms.battery(act)
    val done = listOf(n, m, a, b).count { it }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        H1(L.t("सेटिंग", "Settings"))

        Panel {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(L.t("भाषा", "Language"), color = DS.text, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    GhostButton((if (Store.lang == "hi") "✓ " else "") + "हिंदी", Modifier.weight(1f)) { Store.setLang(act, "hi") }
                    GhostButton((if (Store.lang == "en") "✓ " else "") + "English", Modifier.weight(1f)) { Store.setLang(act, "en") }
                }
            }
        }

        Muted(L.t("तैयारी: 4 में से $done पूरे", "Setup: $done of 4 done"), 15)
        Box(Modifier.fillMaxWidth().height(8.dp).clip(CircleShape).background(DS.surface2)) {
            Box(Modifier.fillMaxWidth(done / 4f).fillMaxHeight().clip(CircleShape).background(DS.accent))
        }

        SetupRow("🔔", L.t("नोटिफ़िकेशन पढ़ने की अनुमति", "Read notifications"), L.t("ग्राहक के मैसेज पढ़ने के लिए", "To read customer messages"), n) {
            act.open(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
        }
        SetupRow("🎙️", L.t("माइक", "Microphone"), L.t("आपकी आवाज़ सुनने के लिए", "To hear your voice"), m) { act.requestMic() }
        SetupRow("✍️", L.t("चैट बॉक्स में ड्राफ़्ट लिखना", "Write draft in chat box"), L.t("सिर्फ़ ड्राफ़्ट भरता है, Send नहीं दबाता", "Only fills the draft, never presses Send"), a) {
            act.open(Settings.ACTION_ACCESSIBILITY_SETTINGS)
        }
        SetupRow("🔋", L.t("बैटरी बंद न करे", "Keep running in background"), L.t("ऐप चालू रहे इसलिए", "So the app stays alive"), b) { act.openBattery() }

        Panel {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(L.t("अगर सेटिंग में बटन ग्रे है", "If the setting button is greyed out"), color = DS.text, fontWeight = FontWeight.Bold)
                Muted(
                    L.t("फ़ोन सेटिंग > ऐप्स > Driver Saathi > ऊपर ⋮ > \"Restricted settings\" को Allow करें। फिर दोबारा कोशिश करें।",
                        "Phone Settings > Apps > Driver Saathi > top ⋮ > allow \"Restricted settings\". Then try again."), 13
                )
            }
        }

        Panel {
            Row(
                Modifier.fillMaxWidth().padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(Modifier.weight(1f)) {
                    Text(L.t("टेस्ट मोड", "Test mode"), color = DS.text, fontWeight = FontWeight.Bold)
                    Muted(L.t("किसी भी ऐप की नोटिफ़िकेशन पढ़ो (जाँच के लिए)", "Read notifications of any app (for testing)"), 13)
                }
                Switch(
                    checked = Store.testMode(act),
                    onCheckedChange = { Store.setTestMode(act, it) },
                    colors = SwitchDefaults.colors(
                        checkedTrackColor = DS.accent, checkedThumbColor = Color.White, checkedBorderColor = DS.accent,
                        uncheckedTrackColor = DS.surface2, uncheckedThumbColor = DS.muted, uncheckedBorderColor = DS.line
                    )
                )
            }
        }

        PrimaryButton("🔊 " + L.t("आवाज़ टेस्ट करें", "Test voice")) {
            Speaker.speak(L.t("नमस्ते, मैं ड्राइवर साथी हूँ। मेरी आवाज़ सुनाई दे रही है?", "Hello, I am Driver Saathi. Can you hear me?"))
        }

        if (Config.OTP_ENABLED && Store.loggedIn(act)) {
            Panel {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(L.t("खाता", "Account"), color = DS.text, fontWeight = FontWeight.Bold)
                    Muted("+91 ${Store.phone(act)}")
                    GhostButton(L.t("लॉग आउट", "Log out"), Modifier.fillMaxWidth()) { Store.logout(act) }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}
