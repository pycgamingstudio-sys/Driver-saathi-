package com.driversaathi.app

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : ComponentActivity() {

    private var recognizer: SpeechRecognizer? = null

    private val micLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { Store.bump() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.loadLang(this)
        Speaker.init(this)
        setContent { AppTheme { Root(this) } }
    }

    override fun onResume() {
        super.onResume()
        Store.bump()
    }

    override fun onDestroy() {
        recognizer?.destroy()
        super.onDestroy()
    }

    fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    fun requestMic() = micLauncher.launch(Manifest.permission.RECORD_AUDIO)

    fun open(action: String) {
        try { startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (e: Exception) { toast(L.t("सेटिंग नहीं खुली", "Could not open settings")) }
    }

    fun openBattery() {
        try {
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                    .setData(Uri.parse("package:$packageName"))
            )
        } catch (e: Exception) { open(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS) }
    }

    fun copy(text: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("draft", text))
        toast(L.t("कॉपी हो गया", "Copied"))
    }

    /** Opens Ola / Uber / Rapido driver app (found by app name). */
    fun openRide(key: String) {
        val pm = packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val matches = pm.queryIntentActivities(q, 0).filter {
            val label = it.loadLabel(pm).toString().lowercase()
            label.contains(key) || Platforms.of(it.activityInfo.packageName)?.lowercase() == key
        }
        val driverWords = listOf("driver", "captain", "partner", "drive")
        val pick = matches.firstOrNull { m ->
            val l = m.loadLabel(pm).toString().lowercase()
            driverWords.any { l.contains(it) }
        } ?: matches.firstOrNull()
        val intent = pick?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
        if (intent == null) { toast(L.t("$key ऐप नहीं मिला", "$key app not found")); return }
        startActivity(intent)
    }

    /** Listens once and returns the spoken text. */
    fun listen(onText: (String) -> Unit) {
        if (!Perms.mic(this)) { requestMic(); return }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            toast(L.t("आवाज़ पहचान उपलब्ध नहीं", "Voice recognition not available")); return
        }
        recognizer?.destroy()
        val sr = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = sr
        val again = L.t("सुनाई नहीं दिया, दोबारा बोलिए।", "I did not catch that, please speak again.")
        sr.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { toast(L.t("बोलिए…", "Speak now…")) }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) { toast(again) }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onResults(results: Bundle?) {
                val said = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (said.isNullOrBlank()) { toast(again); return }
                onText(said)
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (Store.lang == "hi") "hi-IN" else "en-IN")
        }
        sr.startListening(i)
    }

    /** Driver speaks a reply; AI makes a polite draft. Driver always presses Send himself. */
    fun voiceDraft() = listen { said ->
        val last = Store.messages(this).firstOrNull()
        val incoming = last?.let { "${it.title} ${it.text}".trim() } ?: ""
        Api.assist(this, "draft", last?.platform, incoming, said) { ok, reply ->
            val draft = if (ok) reply else Drafter.fromSpeech(said)
            Store.setPending(this, draft)
            Store.attachDraftToLast(this, draft)
            Speaker.speak(L.t("ठीक है, लिख रहा हूँ: $draft", "Okay, writing: $draft"))
            Store.bump()
        }
    }

    /** AI chat (ChatGPT style). */
    fun sendChat(text: String) {
        val t = text.trim()
        if (t.isBlank() || Store.chatBusy) return
        Store.chat.add(ChatMsg(true, t))
        Store.chatBusy = true
        Api.assist(this, "chat", null, "", t) { ok, reply ->
            Store.chat.add(ChatMsg(false, reply, error = !ok))
            Store.chatBusy = false
        }
    }
}
