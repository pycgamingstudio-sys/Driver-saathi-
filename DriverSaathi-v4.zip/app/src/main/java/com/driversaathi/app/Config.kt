package com.driversaathi.app

object Config {
    /** Your live Lovable backend. */
    const val BASE_URL = "https://saathi-copilot-ai.lovable.app"

    /** Same value as APP_TOKEN secret in Lovable. Leave "" if you did not set one. */
    const val APP_TOKEN = ""

    /** true = phone OTP login required. false = skip login (use only to test AI before OTP backend is ready). */
    const val OTP_ENABLED = true
}
