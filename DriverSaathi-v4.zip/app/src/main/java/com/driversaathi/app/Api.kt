package com.driversaathi.app

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Api {
    private val main = Handler(Looper.getMainLooper())

    private fun call(c: Context, path: String, body: JSONObject, cb: (Int, JSONObject?, String) -> Unit) {
        val app = c.applicationContext
        Thread {
            var code = -1
            var raw = ""
            try {
                val conn = URL(Config.BASE_URL + path).openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.connectTimeout = 15000
                conn.readTimeout = 40000
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json")
                if (Config.APP_TOKEN.isNotBlank()) conn.setRequestProperty("x-app-token", Config.APP_TOKEN)
                val tok = Store.token(app)
                if (tok.isNotBlank()) conn.setRequestProperty("Authorization", "Bearer $tok")
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                raw = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            } catch (e: Exception) {
                code = -1
            }
            val json = try { JSONObject(raw) } catch (e: Exception) { null }
            main.post { cb(code, json, raw) }
        }.start()
    }

    private fun pick(o: JSONObject?, raw: String): String {
        if (o != null) {
            for (k in listOf("reply", "draft", "text", "message", "answer", "response", "output", "result", "error")) {
                val v = o.optString(k, "")
                if (v.isNotBlank() && v != "null") return v
            }
            val d = o.optJSONObject("data")
            if (d != null) return pick(d, "")
        }
        return raw.trim()
    }

    /** mode = "chat" or "draft". cb(ok, text) runs on main thread. */
    fun assist(
        c: Context, mode: String, platform: String?, incoming: String, speech: String,
        cb: (Boolean, String) -> Unit
    ) {
        val body = JSONObject()
            .put("mode", mode)
            .put("device_id", Store.deviceId(c))
            .put("platform", if (platform in listOf("Uber", "Ola", "Rapido")) platform else JSONObject.NULL)
            .put("incoming_message", incoming.take(500))
            .put("driver_speech", speech.take(500))
        call(c, "/api/public/ai-assist", body) { code, json, raw ->
            when {
                code in 200..299 -> {
                    val t = pick(json, raw)
                    if (t.isBlank()) cb(false, L.t("जवाब खाली आया।", "Got an empty reply."))
                    else if (t.contains("AI not configured", true)) cb(false, L.t("AI अभी चालू नहीं है।", "AI is not set up yet."))
                    else cb(true, t)
                }
                code == 429 -> cb(false, pick(json, "").ifBlank { L.t("बहुत ज़्यादा रिक्वेस्ट। थोड़ी देर बाद कोशिश करें।", "Too many requests. Try again shortly.") })
                code == -1 -> cb(false, L.t("इंटरनेट नहीं है। नेट जाँचिए।", "No internet. Please check your connection."))
                else -> cb(false, L.t("AI अभी जवाब नहीं दे पा रहा। थोड़ी देर बाद कोशिश करें।", "AI could not answer right now. Please try again later."))
            }
        }
    }

    fun sendOtp(c: Context, phone: String, cb: (Boolean, String) -> Unit) {
        call(c, "/api/public/auth/send-otp", JSONObject().put("phone", "+91$phone")) { code, json, raw ->
            if (code in 200..299) cb(true, "")
            else if (code == 404) cb(false, L.t("सर्वर पर OTP अभी तैयार नहीं है।", "OTP is not set up on the server yet."))
            else if (code == -1) cb(false, L.t("इंटरनेट नहीं है।", "No internet."))
            else cb(false, pick(json, "").ifBlank { L.t("OTP नहीं भेज पाए। दोबारा कोशिश करें।", "Could not send OTP. Try again.") })
        }
    }

    fun verifyOtp(c: Context, phone: String, otp: String, cb: (Boolean, String) -> Unit) {
        val body = JSONObject().put("phone", "+91$phone").put("otp", otp)
        call(c, "/api/public/auth/verify-otp", body) { code, json, _ ->
            if (code in 200..299) {
                val tok = json?.optString("token", "").orEmpty().ifBlank { json?.optString("access_token", "").orEmpty() }
                Store.login(c, phone, tok.ifBlank { "ok" })
                cb(true, "")
            } else if (code == -1) cb(false, L.t("इंटरनेट नहीं है।", "No internet."))
            else cb(false, pick(json, "").ifBlank { L.t("OTP ग़लत है।", "Wrong OTP.") })
        }
    }
}
