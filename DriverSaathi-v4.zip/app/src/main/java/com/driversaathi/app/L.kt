package com.driversaathi.app

/** Tiny translator: L.t("हिंदी", "English"). Whole app follows Store.lang. */
object L {
    fun t(hi: String, en: String): String = if (Store.lang == "hi") hi else en
}
