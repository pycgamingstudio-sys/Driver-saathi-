# Driver Saathi v4

Hindi/English voice + AI copilot for ride-app drivers.
- Whole app switches Hindi <-> English (top-right button)
- Phone number + OTP login / register
- ChatGPT-style AI chat (Gemini via your Lovable backend)
- Voice reply -> AI draft -> written in the ride app chat box (driver always presses Send)

## Build the APK
Push this folder to GitHub (project files at repo ROOT). Actions tab -> "Build APK" -> download artifact DriverSaathi-APK.

## Settings: app/src/main/java/com/driversaathi/app/Config.kt
- BASE_URL    your Lovable address (already set)
- APP_TOKEN   same as the APP_TOKEN secret in Lovable ("" if not set)
- OTP_ENABLED false = skip login to test AI before the OTP backend is ready
