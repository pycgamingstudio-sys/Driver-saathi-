package com.driversaathi.app

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {

    private var recognizer: SpeechRecognizer? = null

    private val micLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { Store.bump() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Speaker.init(this)
        setContent { AppTheme { Root(this) } }
    }

    override fun onResume() {
        super.onResume()
        Store.bump()
    }

    override fun onDestroy() {
        recognizer?.destroy()
        super.onDestroy()
    }

    fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    fun requestMic() = micLauncher.launch(Manifest.permission.RECORD_AUDIO)

    fun open(action: String) {
        try { startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (e: Exception) { toast("सेटिंग नहीं खुली") }
    }

    fun openBattery() {
        try {
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                    .setData(Uri.parse("package:$packageName"))
            )
        } catch (e: Exception) { open(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS) }
    }

    fun copy(text: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("draft", text))
        toast("कॉपी हो गया")
    }

    /** Opens Ola / Uber / Rapido driver app (found by app name, so no package guessing). */
    fun openRide(key: String) {
        val pm = packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val matches = pm.queryIntentActivities(q, 0).filter {
            val label = it.loadLabel(pm).toString().lowercase()
            label.contains(key) || Platforms.of(it.activityInfo.packageName)?.lowercase() == key
        }
        val driverWords = listOf("driver", "captain", "partner", "drive")
        val pick = matches.firstOrNull { m ->
            val l = m.loadLabel(pm).toString().lowercase()
            driverWords.any { l.contains(it) }
        } ?: matches.firstOrNull()
        val intent = pick?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
        if (intent == null) { toast("$key ऐप नहीं मिला"); return }
        startActivity(intent)
    }

    /** Driver speaks the reply; we make a draft. Driver always presses Send himself. */
    fun listen() {
        if (!Perms.mic(this)) { requestMic(); return }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { toast("आवाज़ पहचान उपलब्ध नहीं"); return }
        recognizer?.destroy()
        val sr = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = sr
        sr.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { toast("बोलिए…") }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) { Speaker.speak("सुनाई नहीं दिया, दोबारा बोलिए।") }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onResults(results: Bundle?) {
                val said = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (said.isNullOrBlank()) {
                    Speaker.speak("सुनाई नहीं दिया, दोबारा बोलिए।")
                    return
                }
                val draft = Drafter.fromSpeech(said)
                Store.setPending(this@MainActivity, draft)
                Store.attachDraftToLast(this@MainActivity, draft)
                Speaker.speak("ठीक है, लिख रहा हूँ: $draft")
                Store.bump()
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
        }
        sr.startListening(i)
    }
}

// ------------------------------------------------------------------ UI

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Color(0xFF2F5BFF),
            background = Color(0xFFF7F8FC),
            surface = Color.White,
            onBackground = Color(0xFF0F1B3D),
            onSurface = Color(0xFF0F1B3D)
        ),
        content = content
    )
}

@Composable
fun CardBox(content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        content = content
    )
}

@Composable
fun Root(act: MainActivity) {
    val tick = Store.tick
    var tab by remember { mutableIntStateOf(0) }

    if (!Store.consent(act)) {
        ConsentScreen { Store.setConsent(act) }
        return
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                listOf("घर", "तैयारी", "संदेश").forEachIndexed { i, label ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Text(listOf("🏠", "⚙️", "💬")[i]) },
                        label = { Text(label) }
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> HomeScreen(act, tick) { tab = 1 }
                1 -> SetupScreen(act, tick)
                else -> MessagesScreen(act, tick)
            }
        }
    }
}

@Composable
fun ConsentScreen(onAgree: () -> Unit) {
    var checked by remember { mutableStateOf(false) }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Spacer(Modifier.height(24.dp))
        Text("आपकी सहमति", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        CardBox {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("• ऐप सिर्फ़ आपके बोलने पर चैट बॉक्स में मैसेज लिखेगा।")
                Text("• Send, Accept और Reject का बटन हमेशा आप ही दबाएँगे।")
                Text("• आपकी आवाज़ रिकॉर्ड या सेव नहीं होती।")
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = checked, onCheckedChange = { checked = it })
            Text("मैं सहमत हूँ")
        }
        Button(
            onClick = onAgree,
            enabled = checked,
            modifier = Modifier.fillMaxWidth().height(56.dp)
        ) { Text("आगे बढ़ें") }
    }
}

@Composable
fun HomeScreen(act: MainActivity, tick: Int, goSetup: () -> Unit) {
    val online = Store.online(act)
    val last = Store.messages(act).firstOrNull()
    val ready = Perms.notifAccess(act)

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("नमस्ते", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)

        CardBox {
            Row(
                Modifier.fillMaxWidth().padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        if (online) "ऑनलाइन" else "ऑफ़लाइन",
                        style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold
                    )
                    Text(if (online) "सुन रहा हूँ" else "बंद है", color = Color.Gray)
                }
                Switch(checked = online, onCheckedChange = { Store.setOnline(act, it) })
            }
        }

        if (!ready) {
            CardBox {
                Row(
                    Modifier.fillMaxWidth().padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("सेटअप अधूरा है", fontWeight = FontWeight.Bold)
                    Button(onClick = goSetup) { Text("पूरा करें") }
                }
            }
        }

        CardBox {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("आख़िरी मैसेज", color = Color.Gray)
                if (last == null) {
                    Text("अभी कोई मैसेज नहीं आया।")
                } else {
                    Text("${last.platform} • ${last.title}", fontWeight = FontWeight.Bold)
                    Text(last.text)
                    if (last.draft.isNotBlank()) {
                        Text("ड्राफ़्ट: ${last.draft}", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                        OutlinedButton(
                            onClick = { act.copy(last.draft) },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("कॉपी करें") }
                    }
                    OutlinedButton(
                        onClick = { Speaker.speak("${last.platform}। ${last.title}। ${last.text}") },
                        modifier = Modifier.fillMaxWidth().height(52.dp)
                    ) { Text("दोबारा सुनाओ") }
                    Button(
                        onClick = { act.listen() },
                        modifier = Modifier.fillMaxWidth().height(56.dp)
                    ) { Text("🎤 बोलकर जवाब दें") }
                }
            }
        }

        Text("ऐप खोलें", color = Color.Gray)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("ola" to "Ola", "uber" to "Uber", "rapido" to "Rapido").forEach { (key, label) ->
                OutlinedButton(
                    onClick = { act.openRide(key) },
                    modifier = Modifier.weight(1f).height(56.dp)
                ) { Text(label) }
            }
        }

        Text("Send हमेशा आप दबाते हैं।", color = Color.Gray)
    }
}

@Composable
fun SetupRow(title: String, desc: String, ok: Boolean, onFix: () -> Unit) {
    CardBox {
        Row(
            Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold)
                Text(desc, color = Color.Gray)
            }
            if (ok) Text("✅", style = MaterialTheme.typography.titleLarge)
            else Button(onClick = onFix) { Text("ठीक करें") }
        }
    }
}

@Composable
fun SetupScreen(act: MainActivity, tick: Int) {
    val n = Perms.notifAccess(act)
    val m = Perms.mic(act)
    val a = Perms.a11y(act)
    val b = Perms.battery(act)
    val done = listOf(n, m, a, b).count { it }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("ऐप तैयार करें", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("4 में से $done पूरे", color = Color.Gray)

        SetupRow("नोटिफ़िकेशन पढ़ने की अनुमति", "ग्राहक के मैसेज पढ़ने के लिए", n) {
            act.open(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
        }
        SetupRow("माइक", "आपकी आवाज़ सुनने के लिए", m) { act.requestMic() }
        SetupRow("चैट बॉक्स में ड्राफ़्ट लिखना", "सिर्फ़ ड्राफ़्ट भरता है, Send नहीं दबाता", a) {
            act.open(Settings.ACTION_ACCESSIBILITY_SETTINGS)
        }
        SetupRow("बैटरी बंद न करे", "ऐप चालू रहे इसलिए", b) { act.openBattery() }

        CardBox {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("अगर सेटिंग में बटन ग्रे है", fontWeight = FontWeight.Bold)
                Text(
                    "फ़ोन सेटिंग > ऐप्स > Driver Saathi > ऊपर ⋮ > \"Restricted settings\" को Allow करें। फिर दोबारा कोशिश करें।",
                    color = Color.Gray
                )
            }
        }

        CardBox {
            Row(
                Modifier.fillMaxWidth().padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(Modifier.weight(1f)) {
                    Text("टेस्ट मोड", fontWeight = FontWeight.Bold)
                    Text("किसी भी ऐप की नोटिफ़िकेशन पढ़ो (जाँच के लिए)", color = Color.Gray)
                }
                Switch(checked = Store.testMode(act), onCheckedChange = { Store.setTestMode(act, it) })
            }
        }

        OutlinedButton(
            onClick = { Speaker.speak("नमस्ते, मैं ड्राइवर साथी हूँ। मेरी आवाज़ सुनाई दे रही है?") },
            modifier = Modifier.fillMaxWidth().height(56.dp)
        ) { Text("🔊 आवाज़ टेस्ट करें") }
    }
}

@Composable
fun MessagesScreen(act: MainActivity, tick: Int) {
    val list = Store.messages(act)
    val fmt = remember { SimpleDateFormat("hh:mm a", Locale.getDefault()) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("संदेश", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        if (list.isEmpty()) {
            Text("अभी कोई मैसेज नहीं आया।", color = Color.Gray)
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(list) { m ->
                    CardBox {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("${m.platform} • ${fmt.format(Date(m.time))}", color = Color.Gray)
                            Text(m.title, fontWeight = FontWeight.Bold)
                            Text(m.text)
                            if (m.draft.isNotBlank()) {
                                Text("ड्राफ़्ट: ${m.draft}", color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            }
        }
    }
}
